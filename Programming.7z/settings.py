# Screen settings
WIDTH, HEIGHT = 600, 600

# Tuples for Colors
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
ORANGE = (255, 165, 0)
BLUE = (0, 0, 255)
GRAY = (128, 128, 128,)
PELLET_COLOR = ORANGE